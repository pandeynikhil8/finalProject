package com.capgemini.appl.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity(name="programScheduled")
@Table(name="PROGRAMS_SCHEDULED ")
@SequenceGenerator(name="prgmscheduled_generate",sequenceName="SCHEDULED_PROGRAM_ID",allocationSize=1,initialValue=501)
public class ProgramsScheduled {
	
	int scheduled_program_id;
	//String ProgramName;
	String LocationID;
	java.sql.Date start_date;
	java.sql.Date end_date;
	int sessions_per_week;
    private Location location;
	ProgramsOffered program;
	List<Application> application;
	
	
	@OneToMany(mappedBy = "scheduled")
	public List<Application> getApplication() {
		return application;
	}

	public void setApplication(List<Application> application) {
		this.application = application;
	}

	@Id
	@Column(name="SCHEDULED_PROGRAM_ID")
	@GeneratedValue(generator="prgmscheduled_generate",strategy=GenerationType.SEQUENCE)
	public int getScheduled_program_id() {
		return scheduled_program_id;
	}

	public void setScheduled_program_id(int scheduled_program_id) {
		this.scheduled_program_id = scheduled_program_id;
	}

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="ProgramName")
	public ProgramsOffered getProgram() {
		return program;
	}

	public void setProgram(ProgramsOffered program) {
		this.program = program;
	}

	
	/*
	@NotEmpty(message="Name is required")
	@Column(name="PROGRAMNAME")
	public String getProgramName() {
		return ProgramName;
	}

	public void setProgramName(String programName) {
		ProgramName = programName;
	}
*/
	@Column(name="LOCATIONID")
	public String getLocationID() {
		return LocationID;
	}

	public void setLocationID(String locationID) {
		LocationID = locationID;
	}
	@NotEmpty(message="Start Date is required")
	@Column(name="START_DATE")
	public java.sql.Date getStart_date() {
		return start_date;
	}

	public void setStart_date(java.sql.Date start_date) {
		this.start_date = start_date;
	}
	@NotEmpty(message="End Date is required")
	@Column(name="END_DATE")
	public java.sql.Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(java.sql.Date end_date) {
		this.end_date = end_date;
	}

	@NotEmpty(message="session per week is required")
	@Column(name="SESSIONS_PER_WEEK")
	public int getSessions_per_week() {
		return sessions_per_week;
	}

	public void setSessions_per_week(int sessions_per_week) {
		this.sessions_per_week = sessions_per_week;
	}
	
	
/*	@OneToOne()
	@JoinColumn(name="LOCATIONID")
	public Location getLocation(){
		return location;
	}*/
	
/*	  public void setLocation(Location location) {
	        this.location = location;
	    }*/
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="locationid")
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "ProgramsScheduled [scheduled_program_id="
				+ scheduled_program_id + ", LocationID=" + LocationID
				+ ", start_date=" + start_date + ", end_date=" + end_date
				+ ", sessions_per_week=" + sessions_per_week + ", location="
				+ location + ", program=" + program + "]";
	}

	
}
