package com.capgemini.appl.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity(name="Participant")
@Table(name="Participant")
@NamedQueries({
	@NamedQuery(name="qryAllPartcipant", query="select p from Participant p"),
})
@SequenceGenerator(name="rollNo_generate", sequenceName="roll_no", allocationSize=1, initialValue=1)
//@SequenceGenerator(name="applicationId_generate", sequenceName="application_id", allocationSize=1, initialValue=1)
public class Participant implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String Roll_no;
	private String email_id;
	private int Application_id;
	private String Scheduled_program_id;
	
	
	public Participant() {
		super();
	}
	public Participant(String roll_no, String email_id, int application_id,
			String scheduled_program_id) {
		super();
		Roll_no = roll_no;
		this.email_id = email_id;
		Application_id = application_id;
		Scheduled_program_id = scheduled_program_id;
	}

	@Id
	@Column(name="Roll_no")
	@GeneratedValue(generator="rollNo_generate", strategy=GenerationType.SEQUENCE)
	public String getRoll_no() {
		return Roll_no;
	}
	public void setRoll_no(String roll_no) {
		Roll_no = roll_no;
	}

	@Column(name="email_id")
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	@Id
	@Column(name="Application_id")
	public int getApplication_id() {
		return Application_id;
	}
	public void setApplication_id(int application_id) {
		Application_id = application_id;
	}

	 
	@Column(name="Scheduled_program_id ")
	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(String scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}


	@Override
	public String toString() {
		return "Participant [Roll_no=" + Roll_no + ", email_id=" + email_id
				+ ", Application_id=" + Application_id
				+ ", Scheduled_program_id=" + Scheduled_program_id + "]";
	}

}
