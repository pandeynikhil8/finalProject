package com.capgemini.appl.dto;



import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity(name = "Application")
@Table(name = "APPLICATION")
////////////////////////////////////////////////////////////@NamedQuery
@NamedQueries({
	@NamedQuery(name = "qryAllAppl", query = "select e from Application e")
	 })
/////////////////
@SequenceGenerator(name = "appl_seq_generater", sequenceName = "application_id", allocationSize = 1, initialValue = 1)
public class Application {
	private int Application_id;
	private String full_name;
	private java.sql.Date date_of_birth;
	private String highest_qualification;
	private int marks_obtained;
	private String goals;
	private String email_id;
	//private String Scheduled_program_id;
	private ProgramsScheduled scheduled;
	private String status;
	private java.sql.Date Date_Of_Interview;
	
	
	
    @Id
	@GeneratedValue(generator = "appl_seq_generater", strategy = GenerationType.SEQUENCE)
	@Column(name="Application_id")
	public int getApplication_id() {
		return Application_id;
	}
	public void setApplication_id(int application_id) {
		Application_id = application_id;
	}
	
	@Size(max=40,min=1,message="Please Enter Valid Name")
	@NotEmpty(message="name is required")
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	

	@Past(message="date of birth should be less than todays date")
	public java.sql.Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(java.sql.Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	
	
	@NotEmpty(message="Qualification is required")
	public String getHighest_qualification() {
		return highest_qualification;
	}
	public void setHighest_qualification(String highest_qualification) {
		this.highest_qualification = highest_qualification;
	}
	
	@Size(min=40,max=100,message="Minimum 40% is required")
	public int getMarks_obtained() {
		return marks_obtained;
	}
	public void setMarks_obtained(int marks_obtained) {
		this.marks_obtained = marks_obtained;
	}
	
	
	@NotEmpty(message="Goal should not be empty")
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	
	@Email(message="please Enter valid email")
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	
	/*@NotEmpty(message="please Enter Schedule")
	public String getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(String scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}*/
	
	
	@NotEmpty(message="Enter status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public java.sql.Date getDate_Of_Interview() {
		return Date_Of_Interview;
	}
	public void setDate_Of_Interview(java.sql.Date date_Of_Interview) {
		Date_Of_Interview = date_Of_Interview;
	}
	
	
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="Scheduled_program_id")
	public ProgramsScheduled getScheduled() {
		return scheduled;
	}
	public void setScheduled(ProgramsScheduled scheduled) {
		this.scheduled = scheduled;
	}
	@Override
	public String toString() {
		return "Application [Application_id=" + Application_id + ", full_name="
				+ full_name + ", date_of_birth=" + date_of_birth
				+ ", highest_qualification=" + highest_qualification
				+ ", marks_obtained=" + marks_obtained + ", goals=" + goals
				+ ", email_id=" + email_id + ", scheduled=" + scheduled
				+ ", status=" + status + ", Date_Of_Interview="
				+ Date_Of_Interview + "]";
	}
	

	
}
