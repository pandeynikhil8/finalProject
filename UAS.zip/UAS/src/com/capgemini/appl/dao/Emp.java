package com.capgemini.appl.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;



@Entity(name = "Employee")
@Table(name = "EMPLOYEE")
@NamedQueries({
		@NamedQuery(name = "qryAllEmp", query = "select e from Employee e"),
		 })
@SequenceGenerator(name = "seq_generater", sequenceName = "hibernate_sequence", allocationSize = 1, initialValue = 1)
public class Emp implements Serializable {

	private static final long serialVersionUID = 1L;
	private int empno;
	private String empName;
	
	private String gender;
	private String designation;
	private String email;
	private String phone;

	@Id
	@GeneratedValue(generator = "seq_generater", strategy = GenerationType.SEQUENCE)
	@Column(name="EMPLOYEE_CODE")
	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	@Column(name = "EMPLOYEE_NAME")
	@Size(max=40,min=1,message="Please Enter Valid Name")
	@NotEmpty(message="name is required")
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	
	@Column(name = "EMPLOYEE_GENDER")
	@NotEmpty(message="Please Select your Gender")
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@NotEmpty(message="Please Select Designation")
	@Column(name = "DESIGNATION_NAME")
	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	@NotEmpty(message="Please Enter Email id")
	@Email(message="Please Enter Valid Email id")
	@Column(name = "EMPLOYEE_EMAIL")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	@NotEmpty(message="Please Valid Phone No")
	@Size(max=10,min=10,message="Please Enter Valid Phone No")
	@Pattern(regexp = "^[1-9][0-9]+$", message = "Phone Number should contain only 10 digits And should not start from Zero ")
	@Column(name = "EMPLOYEE_PHONE")
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "Emp [empno=" + empno + ", empName=" + empName + ", gender="
				+ gender + ", designation=" + designation + ", email=" + email
				+ ", phone=" + phone + "]";
	}



}
