/*********************************************************************
 * File                 : EmpCrudController.java
 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA Controller
 * Version              : 1.0
 * Creation Date        : 31-Mar-2017
 * Last Modified Date   : 31-Mar-2017
 *********************************************************************/
package com.capgemini.appl.controlers;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;


@Controller
public class UniversityCrudController {
	private UniversityService service;
	//List<String> designation;

	
	@Resource(name = "universityService")
	public void setEmpServices(UniversityService service) {
		this.service = service;
	}

	//Default Page of Project
	@RequestMapping("index")
	public ModelAndView welcome() {
		ModelAndView model=new ModelAndView("admin");
		return model;

	}		
	////////////////////////////////////////
	@RequestMapping("showAllProgram")
	public ModelAndView showAllPrograms(){
		
		ModelAndView model=null;
		try {
			model = new ModelAndView("showAllProgram");
			List<ProgramsOffered> list= service.showProgramsOffereds();
			model.addObject("list", list);
		} catch (UniversityAdmissionException e) {
			model= new ModelAndView("errorAdmin");
			model.addObject("errMsg",e.getMessage());
		}
		return model;	
	}
	
	@RequestMapping("showAddProgram")
	public ModelAndView getEntryForm(){
		ModelAndView model= new ModelAndView("addProgram");
		model.addObject("program", new ProgramsOffered()); 
	
		return model;
	}
	
	@RequestMapping("/submitAddProgram.do")
	public ModelAndView submitEntryForm(@ModelAttribute("program")  @Valid ProgramsOffered program, BindingResult result){
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			model.addObject("program",program);
			model.setViewName("addProgram");
			return model;
		}
		try {
			ProgramsOffered programOffered= service.addProgram(program);
			model.addObject("program", programOffered);
			model.setViewName("index");
		
		} catch (UniversityAdmissionException e) {
			model.setViewName("errorAdmin");
			model.addObject("errMsg","Record insertion failed: "+e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("delteProgram")
	public ModelAndView delteProgram(@RequestParam("ProgramName") String ProgramName){
		ModelAndView model= new ModelAndView();
		//model.addObject("program", new ProgramsOffered()); 
		
		List<ProgramsOffered> list;
		try {
			
			
			ProgramsOffered p=new ProgramsOffered();
			p.setProgramName(ProgramName);
			service.deleteProgram(p);
			model = new ModelAndView("showAllProgram");
			list = service.showProgramsOffereds();
			model.addObject("list", list);
		} catch (UniversityAdmissionException e) {
			model.setViewName("errorAdmin");
			model.addObject("errMsg","Record deletion failed: "+e.getMessage());
		}
	
		return model;
	}
	
	
	
	@RequestMapping("updateProgram")
	public ModelAndView updateProgram(@RequestParam("ProgramName") String ProgramName){
		ModelAndView model= new ModelAndView();
		//model.addObject("program", new ProgramsOffered()); 
		System.out.println("xxxxxxxxxxxxxxxx");
		ProgramsOffered programsOffered=new ProgramsOffered();
		programsOffered.setProgramName(ProgramName);
		System.out.println("xxxxxxxxxxxxxxxx");
		try {	System.out.println("xxxxxxxxxxxxxxxx");
			programsOffered=service.getProgram(programsOffered);
			System.out.println("xxxxxxxxxxxxxxxx");
			model = new ModelAndView("showProgram");
			model.addObject("programsOffered", programsOffered);
		} catch (RollbackException | UniversityAdmissionException e) {
			model.setViewName("errorAdmin");
			model.addObject("errMsg","Program Updation failed: "+e.getMessage());
		}
		

		
	
		return model;
	}
	
	
	
	@RequestMapping("updateOneProgram")
	public ModelAndView updateOneProgram(@ModelAttribute("programsOffered")  @Valid ProgramsOffered program, BindingResult result){
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			
			
			ProgramsOffered programsOffered=new ProgramsOffered();
			programsOffered.setProgramName(program.getProgramName());
			model.addObject("programsOffered", programsOffered);
			model.setViewName("showProgram");
			return model;
		}
		try {
			ProgramsOffered programOffered= new ProgramsOffered();
			programOffered=service.updateProgram(program);
			
			if(programOffered!=null)
			{
				model = new ModelAndView("showAllProgram");
				List<ProgramsOffered> list= service.showProgramsOffereds();
				model.addObject("list", list);
			}
			
		
		} catch (UniversityAdmissionException e) {
			model.setViewName("errorAdmin");
			model.addObject("errMsg","Updation of one program failed: "+e.getMessage());
		}
		return model;
	}
	////////////////////////////////////////////////////////
	/*@RequestMapping("applicant")
	public ModelAndView applicant() {
		ModelAndView model=new ModelAndView("applicant");
		return model;
	}

	
	@RequestMapping("showApplicant")
	public ModelAndView showApplicant() {
		ModelAndView modelAndView=null;		try {
			List<Application> list=service.showApplications();
			System.out.println(service.showApplications());
			modelAndView=new ModelAndView("error");
			modelAndView.addObject("msg", list);
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return modelAndView;
	}
	
	
	@RequestMapping("showAddProgram")
	public ModelAndView showaddProgram() {
		ModelAndView modelAndView=new ModelAndView("addProgram");	
		return modelAndView;
	}*/
	/////////////////////////////////////////////////
/*	//show List of Employee
	@RequestMapping("showAllEmps")
	public ModelAndView showAllEmps() {
		ModelAndView model = null;
		try {
			List<Emp> list = service.getAllEmps();
			model = new ModelAndView("showAllEmps");
			model.addObject("list", list);
		} catch (EmpEcxeption e) {
			model = new ModelAndView("error");
			model.addObject("msg", e);
		}
		return model;
	}

	//Navigate to New Employee Entry Form
	@RequestMapping("addNewEmp")
	public ModelAndView addNew(ModelAndView model) {

		Emp emp = new Emp();
		model.addObject("emp", emp);
		model.addObject("designation", designation);
		model.setViewName("addNewEmp");
		return model;

	}

	//Add Employee to Database Or Show error
	@RequestMapping("addEmp")
	public ModelAndView addEmp(@ModelAttribute @Valid Emp emp,
			BindingResult result) {
		ModelAndView model = new ModelAndView();
		if (result.hasErrors()) {
			model.addObject("emp", emp);
			model.addObject("designation", designation);
			model.setViewName("addNewEmp");
			return model;
		}

		try {
			Emp myemp = service.insertNewEmp(emp);
			model.addObject("emp", myemp);
			model.setViewName("successEmp");
			return model;
		} catch (EmpEcxeption e) {
			model.setViewName("error");
			model.addObject("msg", e);
			return model;
		}

	}
*/
	
	
}