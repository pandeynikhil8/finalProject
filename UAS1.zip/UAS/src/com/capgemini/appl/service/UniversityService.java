package com.capgemini.appl.service;

import java.sql.Date;
import java.util.List;

import javax.persistence.RollbackException;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityService {

	ProgramsOffered addProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	ProgramsOffered getProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	ProgramsOffered deleteProgram(ProgramsOffered p) throws UniversityAdmissionException, RollbackException;;

	ProgramsOffered updateProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;


}
