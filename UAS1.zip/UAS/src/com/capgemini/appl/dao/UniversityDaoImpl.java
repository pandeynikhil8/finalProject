package com.capgemini.appl.dao;


import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;


@Repository("universityDao")
public class UniversityDaoImpl implements UniversityDao {
	
	
	@PersistenceContext
	private EntityManager manager;
	

	
	@Override
	public ProgramsOffered addProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException {
		
		try {
			
			manager.persist(p);
			
		} catch (RollbackException e) {
		
			throw new UniversityAdmissionException("Record not inserted",e);
		}
		return p;
		
	}

	@Override
	public ProgramsOffered updateProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException {

			manager.merge(p);
		
		
		return p;
	} 
	

	@Override
	public ProgramsOffered deleteProgram(ProgramsOffered p) throws UniversityAdmissionException, RollbackException {
			
				ProgramsOffered programsOffered=manager.find(ProgramsOffered.class,p.getProgramName());
				
				manager.remove(programsOffered);
		
		
		return p;
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {
		Query query=manager.createNamedQuery("qryAllProgramsOffered", ProgramsOffered.class);
		return query.getResultList();
	}

	@Override
	public ProgramsOffered getProgram(ProgramsOffered p)
			throws UniversityAdmissionException, RollbackException {
		
		ProgramsOffered programsOffered=manager.find(ProgramsOffered.class, p.getProgramName());
		return programsOffered;
	}
	

/*	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {
		Query query = manager.createNamedQuery("qryAllAppl", Application.class);
	//	Query query = manager.createQuery("select e from Application e"); //("select e from APPLICATION e", Application.class);
	
		return query.getResultList();	}

	@Override
	public boolean addProgram(ProgramsOffered p) throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteProgram(String ProgramName) throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProgram(ProgramsOffered p) throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Users getUserDetail(String userName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Application> getApplicationOnSheduledId(String ScheduleId)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateApplicationDB(int id, String status)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ProgramsOffered> getAllProgramDetails()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insertLocationDetails(Location loc)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertScheduledDetails(ProgramsScheduled schedule)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteSchedule(String id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Application> showApplicantInfo(int id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addApplicant(Application appl)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String isUserAuthanticate(String userName, String password)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProgramsScheduled> showProgramInfo(Date startdate, Date enddate)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

*/

}
