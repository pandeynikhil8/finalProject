package com.capgemini.appl.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.RollbackException;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.capgemini.appl.dto.*;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityDao {
///////////////////////////////////////////////////
	ProgramsOffered addProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	ProgramsOffered getProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	ProgramsOffered deleteProgram(ProgramsOffered p) throws UniversityAdmissionException, RollbackException;;

	ProgramsOffered updateProgram(ProgramsOffered p) throws UniversityAdmissionException,RollbackException;
	List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException;

	/*List<ProgramsOffered> getAllProgramDetails() throws UniversityAdmissionException;*/

}
